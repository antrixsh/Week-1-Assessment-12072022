import java.util.*;
public class answer1
{
	public static void main(String[] args)
		{
		Scanner sc=new Scanner(System.in);
		System.out.println("input first number:");
		int w=sc.nextInt();
		System.out.println("input second number:");
		int x=sc.nextInt();
		System.out.println("input third number:");
		int y=sc.nextInt();
		System.out.println("input fourth number:");
		int z=sc.nextInt();
		if(w==x)
			{
			if(x==y)
				{
				if(y==z)
					{
					System.out.println("All four are equal");
                                        }
                               }                              
                        }
		else
		System.out.println("All are not equal");
	}
 }
	
