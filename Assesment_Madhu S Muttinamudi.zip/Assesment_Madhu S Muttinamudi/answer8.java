import java.util.*;

public class answer8{
	public static void read(int array[],int n){
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<n;i++){
			array[i]=sc.nextInt();
}}

	public static void main(String[] args){
		
		Scanner sc=new Scanner(System.in);
		System.out.print("enter the number of elements in array1:");
		int n1=sc.nextInt();
		int array[]=new int[n1];
		System.out.print("enter the array1:");
		read(array,n1);
		System.out.print("enter the number of elements in array2:");
		int n2=sc.nextInt();
		int array1[]=new int[n2];
		System.out.print("enter the array2:");
		read(array1,n2);
		int m=n1+n2;
		int array2[]=new int[m];
		for(int i=0;i<n1;i++){
			array2[i]=array[i];}
		for(int i=n1;i<m;i++){
			array2[i]=array1[i-n1];}
		System.out.print("Output:");
		for(int i=0;i<m;i++){
				System.out.print(array2[i]+" ");
}
}
}

		
	
