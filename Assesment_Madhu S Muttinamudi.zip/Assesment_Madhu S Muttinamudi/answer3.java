import java.util.*;
public class answer3{
	public static void main(String[] args){
		boolean array[][]=new boolean[2][3];
		Scanner sc=new Scanner(System.in);
		System.out.print("enter the array:");
		for(int i=0;i<2;i++){
		for(int j=0;j<3;j++){
			array[i][j]=sc.nextBoolean();
}}

		for(int i=0;i<2;i++){
		for(int j=0;j<3;j++){
		
			if(array[i][j] == true)
				System.out.print("t ");
			else
				System.out.print("f ");
}
		System.out.println();
}
}
}
			
 