import java.util.*;
public class answer7
             {
	public static void print(int a, int array1[])
                {
	         for(int i=0;i<a;i++)
                            {
				System.out.print(array1[i]+" ");
                            }
                }
	public static void main(String[] args)
             {
		
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the number of elements in array:");
		int n=sc.nextInt();
		System.out.print("Enter the array:");
		int array[]=new int[n];
		int j=0;
		for(int i=0;i<n;i++)
                    {
			array[i]=sc.nextInt();
                    }
		int temp[]=new int[n];
		for(int i=0;i<n-1;i++)
                    {
			if(array[i]!=array[i+1])
				temp[j++]=array[i];
                   }
		temp[j++]=array[n-1];
		for(int i=0;i<j;i++)
			array[i]=temp[i];
		print(j,array);
        }
   }