import java.util.*;
public class Answer8 {
    static void mergeArray(int arr1[], int arr2[]){
        int n = arr1.length;
        int m = arr2.length;

        int arr[] = new int[n + m];

        int k = 0;
        for(int i = 0; i < n; i++){
            arr[k++] = arr1[i];
        }
        for(int j = 0; j < m; j++){
            arr[k++] = arr2[j];
        }

        for(int i = 0; i < arr.length; i++){
            System.out.print(arr[i]  + " ");
        }
    }
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int m = sc.nextInt();
        int arr1[] = new int[n];
        int arr2[] = new int[m];

        for(int i = 0; i < n; i++){
            arr1[i] = sc.nextInt();
        }

        for(int i = 0; i < m; i++){
            arr2[i] = sc.nextInt();
        }

        mergeArray(arr1, arr2);
    }
}