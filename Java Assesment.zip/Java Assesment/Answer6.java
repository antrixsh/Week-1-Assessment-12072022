import java.util.*;
import java.lang.*;
import java.io.*;

public class Answer6 {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Input first Number");
        int n = sc.nextInt();
        int x = n;
       
        int sum = 0;
        
        int count = 0;
        while(x != 0){
            int m = x % 2;
            sum = sum * 10 + m;
            if(m == 0){
                count++;
            }
            x = x / 2;
        }

        String s = Integer.toString(sum);
        char[] ch = s.toCharArray();

        System.out.print("Binary representation of " + n + " is: ");
        for (int i = ch.length - 1; i >= 0; i--){
            System.out.print(ch[i]);
        }
            
       System.out.println();
        System.out.print("Number of zero bits: ");
        System.out.print(count);
    }
}