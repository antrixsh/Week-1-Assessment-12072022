import java.util.*;
public class Answer4 {
    static void transpose(int arr[][], int row, int col){
        int mat[][] = new int[col][row];
        
        for(int i = 0; i < col; i++){
            for(int j = 0; j < row; j++){
                mat[i][j] = arr[j][i];
                System.out.print(mat[i][j] + " ");
            }
            System.out.println();
        }     
    }
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter rows");
        int row = sc.nextInt();
        System.out.println("Enter cols");
        int col = sc.nextInt();
        System.out.println("Enter values");
        int arr[][] = new int[row][col];
        for(int i = 0; i < row; i++){
            for(int j = 0; j < col; j++){
                arr[i][j] = sc.nextInt();
            }
        }
        transpose(arr, row, col);
    }
}