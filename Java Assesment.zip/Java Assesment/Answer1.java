import java.util.*;
public class Answer1 {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Input first Number");
        int a = sc.nextInt();
        System.out.println("Input Second Number");
        int b = sc.nextInt();
        System.out.println("Input Third Number");
        int c = sc.nextInt();
        System.out.println("Input fourth Number");
        int d = sc.nextInt();

        if(a == b && b == c && c == d){
            System.out.print("Numbers are equal");
        }
        else{
            System.out.print("Numbers are not equal");   
        }
    }
}