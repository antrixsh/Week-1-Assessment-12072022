import java.util.Scanner;
public class answer6 {	
	public static int countBitsTozeroBasedOnString(int n) {
    int chr = 0;
    String binaryNumber = Integer.toBinaryString(n);
	System.out.print("Binary representation of "+n+" is: "+binaryNumber);
    for (char ch : binaryNumber.toCharArray()) {
      chr += ch == '0' ? 1 : 0;
    }
    return chr;
  }	
	
    public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int n = in.nextInt();
		System.out.println("\nNumber of 0 bits in the binary representation: " + countBitsTozeroBasedOnString(n));
		}
}