import java.util.Scanner;
public class answer4m 
{
	public static void main(String[] args) 
	{
		int[][] tdm =
		{
				{10, 20, 30},
				{40, 50, 60}
		};
		System.out.print("The given array:\n");
		print_array(tdm);
		System.out.print("The array after changing is:");
		transpose(tdm);
		}
	
	private static void transpose(int[][] tdm)
	{
		
		int[][] newtdm = new int[tdm[0].length][tdm.length];
		
		for (int i = 0; i < tdm.length; i++)
			{
			for (int j = 0; j < tdm[0].length; j++)			
			{
				newtdm[j][i] = tdm[i][j];
			}
		}
		
		print_array(newtdm);
	}
	private static void print_array(int[][] tdm)
	{
		for (int i = 0; i < tdm.length; i++) 
		{
			for (int j = 0; j < tdm[0].length; j++) 
			{
				System.out.print(tdm[i][j] + " ");
			}
			System.out.println();
		}
	
	}
}