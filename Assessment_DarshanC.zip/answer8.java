import java.util.*;
public class answer8{
	public static void main(String args[]){
		int n;  
        Scanner sc=new Scanner(System.in);  
        System.out.print("enter n");  
  
        n=sc.nextInt();  
        int[] arr = new int[n]; 
        int[] arr1=new int[n];		
        System.out.println("enter the 1st array: ");  
        for(int i=0; i<n; i++)  
        {  
          arr[i]=sc.nextInt();  
        }  
		 System.out.println("enter the 2nd array: ");  
        for(int i=0; i<n; i++)  
        {  
          arr1[i]=sc.nextInt();  
        }  
		int x=arr.length;
		int y=arr1.length;
		int z=x+y;
		
		int[] arr2=new int[z];
		
		for(int i=0;i<x;i++)
		{
			arr2[i]=arr[i];
		}
		
		for(int i=0;i<y;i++)
		{
			arr2[x+i]=arr1[i];
		}
		for(int i=0;i<z;i++)
		{
			System.out.print("[ " + arr2[i] + " ]");
		}
	}
}