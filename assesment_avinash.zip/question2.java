import java.util.Scanner;
public class question2 {
 public static void main(String[] args) {


   Scanner in = new Scanner(System.in);

   System.out.print("first number: ");

         double num1 = in.nextDouble();

         System.out.print("second number: ");

         double num2 = in.nextDouble();


   System.out.println(num1 > 0 && num1 < 1 && num2 > 0 && num2 < 1);
 }
}