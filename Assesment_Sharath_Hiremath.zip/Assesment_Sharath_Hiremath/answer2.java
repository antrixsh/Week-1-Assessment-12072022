import java.util.Scanner;
public class answer2{
	public static void main(String[] args){
		Scanner in = new Scanner(System.in);
		System.out.print(" enter the first number");
		double a1 = in.nextDouble();
		System.out.print(" enter the second number");
		double a2 = in.nextDouble();
		System.out.println(a1>0 && a1<1 && a2 > 0 && a2<1);
	}
}

	