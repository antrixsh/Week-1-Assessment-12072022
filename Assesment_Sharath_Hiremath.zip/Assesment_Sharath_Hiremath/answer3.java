import java.util.Scanner;
public class answer3{
	public static void main(String[] args){
		boolean [][]array = {{true,false,true},{false,true,false}};
		int r = array.length;
		int c = array[0].length;
		for(int i = 0;i<r;i++){
			for(int j = 0;j<c;j++){
				if(array[i][j]){
					System.out.print("t");
				}
				else {
					System.out.print("f");
				}
			}
			System.out.println();
		}
	}
}