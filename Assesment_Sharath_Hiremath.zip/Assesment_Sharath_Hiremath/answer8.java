import java.util.Arrays;

public class answer8 {
	public static void main(String[] args)
	{
		 
		int[] a = { 10, 20, 30, 40 };

		 
		int[] b = { 50, 60, 70, 80 };

		
		int a1 = a.length;
		
		 
		int b1 = b.length;
		
	 
		int c1 = a1 + b1;

		 
		int[] c = new int[c1];

		 
		
 
		System.out.println((c));
	}
}
