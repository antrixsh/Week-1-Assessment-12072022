import java.util.Scanner;
public class answer1{
	public static void main(String[] args){
		Scanner in = new Scanner(System.in);
		System.out.print("Enter the first number");
		int i1 = in.nextInt();
		System.out.print("Enter the Second number");
		int i2 = in.nextInt();
		System.out.print("Enter the third number");
		int i3 = in.nextInt();
		System.out.print("Enter the first number");
		int i4 = in.nextInt();
		
		if(i1==i2&& i2==i3 && i3==i4 ){
			System.out.println("Numbers are equal");
		}
		else{
			System.out.println("Numbers are not Equal");
		}
	}
}