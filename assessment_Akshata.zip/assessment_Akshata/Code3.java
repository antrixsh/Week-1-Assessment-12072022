/*Q. 3 Write a Java program to print the contents of a two-dimensional Boolean array where t will represent true and f will represent false.
Sample array:
array = {{true, false, true},
{false, true, false}};
Expected Output :
t f t 
f t f*/

import java.util.*;
public class Code3{
	public static void main(String args[])
	{
		boolean arr[][]={{true, false, true},{false, true, false}};
		String tmpAr[][]=new String[arr.length][arr[0].length];
		
		
		for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[0].length;j++){
                if(arr[i][j]==true)
                tmpAr[i][j]="t";
                else if(arr[i][j]==false)
                tmpAr[i][j]="f";
            }
        }
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[0].length;j++){
                System.out.print(tmpAr[i][j]+" ");
            }
            System.out.println();
		}
	}
}











/*public class answer3 {
    public static void main(String[] args){
        boolean arr[][]={{true,false,true},
                        {false,true,false}
                        };
        String temparr[][]=new String[arr.length][arr[0].length];

        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[0].length;j++){
                if(arr[i][j]==true)
                temparr[i][j]="t";
                else if(arr[i][j]==false)
                temparr[i][j]="f";
            }
        }
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[0].length;j++){
                System.out.print(temparr[i][j]+" ");
            }
            System.out.println();
        }
    }
}*/