/*Q. 2 Write a Java program that accepts two double variables and test if both strictly between 0 and 1 and false otherwise.
Sample Output:
Input first number: 5
Input second number: 1
false*/

import java.util.*;
public class Code2{
	public static void main(String[] args)
	{
		double num1,num2;
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter First Number: ");
		num1 = sc.nextDouble();
		System.out.print("Enter Second Number: ");
		num2 = sc.nextDouble();
		
		if( (num1 > 0 && num1 < 1) && (num2 > 0 && num2 < 1) )
			System.out.print("true");
		else
			System.out.print("false");
	}
}