/*Q.6 Write a Java program that will accept an integer and convert it into a binary representation.
Now count the number of bits which is equal to zero of the said binary representation.
Expected Output:
Input first number: 25
Binary representation of 25 is: 11001
Number of zero bits: 2
*/

import java.util.*;
public class Code6{
	public static void main(String args[])
	{
		int num1,n;
		int[] num2 = new int [32];
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Integer Number: ");
		num1 = sc.nextInt();
		
		n=num1;
		int i=0;
		
		while(n>0){
			num2[i] = n % 2;
			n = n/2;
			i++;
		}	
		
		int count = 0;
		System.out.print("Binary representation of "+ num1 +" is: ");
		for(int j=i-1;j>=0;j--){
			System.out.print(num2[j]);
			if(num2[j] == 0 )
				count ++;
		}
		System.out.print("\nNumber of zero bits: "+ count);
		
	}
}