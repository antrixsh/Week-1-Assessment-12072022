/*Q. 1 Write a Java program that accepts four integer from the user and prints equal if all four are equal, and not equal otherwise.
Sample Output:
Input first number: 25
Input second number: 37
Input third number: 45
Input fourth number: 23
Numbers are not equal!*/

import java.util.*;
public class Code1{
	public static void main(String args[])
	{
		int num1,num2,num3,num4;
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter First Number: ");
		num1 = sc.nextInt();
		System.out.print("Enter Second Number: ");
		num2 = sc.nextInt();
		System.out.print("Enter Third Number: ");
		num3 = sc.nextInt();
		System.out.print("Enter Fourth Number: ");
		num4 = sc.nextInt();
		if(num1 == num2 && num2 == num3 && num3 == num4)
					System.out.print("Numbers are equal");
		else
					System.out.print("Numbers are not equal");
	}
}