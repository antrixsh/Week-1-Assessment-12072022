public class answer3 {
    public static void main(String[] args){
        boolean arr[][]={{true,false,true},
                        {false,true,false}
                        };
        String temparr[][]=new String[arr.length][arr[0].length];

        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[0].length;j++){
                if(arr[i][j]==true)
                temparr[i][j]="t";
                else if(arr[i][j]==false)
                temparr[i][j]="f";
            }
        }
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[0].length;j++){
                System.out.print(temparr[i][j]+" ");
            }
            System.out.println();
        }
    }
}
