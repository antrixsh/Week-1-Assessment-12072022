import java.util.*;     // for Scanner class

public class answer1 {
    
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.print("Input first number :");
        int f1= sc.nextInt();
        System.out.print("Input second number :");
        int f2= sc.nextInt();
        System.out.print("Input third number :");
        int f3= sc.nextInt();
        System.out.print("Input fouth number :");
        int f4= sc.nextInt();

        if(f1==f2 && f2==f3 && f3==f4){
            System.out.println("Numbers are equal!");
        }
        else{
            System.out.println("Numbers are not equal!");
        }
        sc.close();     // close the Scanner
        

    }

}
