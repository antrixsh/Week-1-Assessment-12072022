import java.util.*; // for Scanner class
public class answer2 {
    public static void main(String[] args){
            Scanner sc=new Scanner(System.in);
            System.out.print("Enter first number: ");
            double d1 = sc.nextDouble();
            System.out.print("Enter second number: ");
            double d2 = sc.nextDouble();
       
            System.out.println((d1>=0 && d1<=1 && d2>=0 && d2<=1)); // method 1

            //  if(d1>=0 && d1<=1){                                 // method 2
            //     if(d2>=0 && d2<=1){
            //       System.out.println("true");
            //     }
            //     else
            //     System.out.println("false");
            // }
            // else
            // System.out.println("false");

            // if(d1>=0 && d1<=1 && d2>=0 && d2<=1)                 // method 3
            // System.out.println("true");
            // else
            // System.out.println("false");
            sc.close();     // close the Scanner

    }
    
}
