public class answer4 {

    public static void printMatrix(int arr[][]){        //Define Function for printing matrix
        for(int i=0;i<arr.length;i++){
        for(int j=0;j<arr[0].length;j++){
            System.out.print(arr[i][j]+" ");
        }
        System.out.println();
    }

    }
    public static void matrixTranspose(int arr1[][],int tarr[][]){      //Define function to transpose the matrix
        for(int i=0;i<arr1[0].length;i++){
            for(int j=0;j<arr1.length;j++){
                tarr[i][j]=arr1[j][i];
            }
        }
        
    }
    public static void main(String[] args){
         
        int arr[][]={{10,20,30},{40,50,60}};
        int temparr[][]=new int[arr[0].length][arr.length];
        System.out.println("Orignal Array");
        printMatrix(arr);   //call the prinf function
        System.out.println("After changing the rows and columns of the said array:");
        matrixTranspose(arr, temparr); //call the transpose function    
        printMatrix(temparr);    //print the matrix    

    }
    
}
