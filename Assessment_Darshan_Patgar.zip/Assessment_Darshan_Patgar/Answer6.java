import java.util.Scanner;
class Answer6{
    public static void main(String[] args){
        int n;
        String x = "";
        Scanner s = new Scanner(System.in);
        System.out.print("enter integer number:");
        n = s.nextInt();
		int m=n;
        while(m > 0)
        {
            int a = m % 2;
            x = a + x;
            m= m / 2;
        }
        System.out.println("binary representation is :" +x);
		
		int count1=0;
		while(n>0)
		{
			if((n&1)==0)
			{
				count1++;
			}
			n=n>>1;
		}
		System.out.println("number of bits :"+ count1);
    }
}