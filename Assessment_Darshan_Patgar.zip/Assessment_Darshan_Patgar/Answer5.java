import java.util.*;
class Answer5{
	public static void main(String args[]){
		int n;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter n");
		n=sc.nextInt();
		
		int arr[]=new int[n];
		
		System.out.println("enter array elements");
		for(int i=0;i<n;i++){
			arr[i]=sc.nextInt();
		}
		int temp=0;
		for(int i=0;i<arr.length;i++){
			for(int j=0;j<arr.length;j++){
				if(arr[i]>arr[j]){
					temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		}
		
		//to find k largest elements
		int k;
		System.out.println("enter k");
		k=sc.nextInt();
		
		for(int i=0;i<k;i++)
		{
			System.out.println(arr[i] +" ");
		}
	}
}
		