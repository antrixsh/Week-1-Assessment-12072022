import java.util.*;
class Answer3{
	public static void main(String args[]){
		boolean[][] arr= {{true,false,true},{false,true,false}};
		int n=arr.length;
		int m=arr[0].length;
		
		for(int i=0;i<n;i++){
			for(int j=0;j<m;j++){
				if(arr[i][j]){
					System.out.println("t");
				}else{
					System.out.println("f");
				}
			}
		}
	}
}