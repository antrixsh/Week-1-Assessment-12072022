import java.util.*;
class Answer1{
	public static void main(String args[]){
		int a,b,c,d;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter first number");
		a=sc.nextInt();
		System.out.println("enter second number");
		b=sc.nextInt();
		System.out.println("enter third number");
		c=sc.nextInt();
		System.out.println("enter fourth number");
		d=sc.nextInt();
		
		if(a==b && b==c && c==d){
			System.out.println("equal");
		}else{
			System.out.println("numbers are not equal");
		}
	}
}
		
		