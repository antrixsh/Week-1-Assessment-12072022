import java.util.*;
class Answer4{
	public static void main(String args[]){
		int arr[][]={{10,20,30},{40,50,60}};
		int temp[][]=new int[10][10];
		
		
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				temp[i][j]=arr[j][i];
			}
		}
		
		System.out.println("after changing rows and columns");
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				System.out.print(temp[i][j]+" ");
			}
			System.out.println();
		}
	}
}