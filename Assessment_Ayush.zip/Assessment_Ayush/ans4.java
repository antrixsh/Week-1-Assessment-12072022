class ans4{
	public static void main(String args[]){
		int arr[][]={{10,21,32},{22,56,77},{11,21,34},{11,22,33}};
		
		System.out.println("The original array : ");
		originall(arr);
		System.out.println("After changing the rows and columns of the said array: ");
		transposee(arr);
	}
	 
	public static void originall(int arr[][]){
		
		for (int i=0; i<arr.length; i++){
			for (int j =0 ;j <arr[0].length;j++){
				System.out.print(arr[i][j]+" ");
			}
		System.out.println();
		}
	}
	
	public static void transposee(int arr[][]){
		int arr1[][] = new int[arr[0].length][arr.length];
		for (int i=0; i<arr.length; i++){
			for (int j =0 ;j <arr[0].length;j++){
				arr1[j][i]=arr[i][j];
			}
		}
		originall(arr1);
	}
}

		