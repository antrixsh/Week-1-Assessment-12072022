import java.util.Scanner;
public class ans1{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter First no.");
		int n1 = sc.nextInt();
		System.out.println("Enter second no.");
		int n2 = sc.nextInt();
		System.out.println("Enter 3rd no.");
		int n3 = sc.nextInt();
		System.out.println("Enter fourth no.");
		int n4 = sc.nextInt();
		
		if (n1 ==n2 && n2 == n3 &&n3 ==n4)
		{
			System.out.println("Numbers are equal.");
		}
		else
		{
			System.out.println("Numbers are not equal!");
		}
		
	}
}
