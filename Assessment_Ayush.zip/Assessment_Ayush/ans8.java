import java.util.*;
class Q8{
	public static void main(String[] args){
		int[] a ={1,2,3};
		int[] b ={4,5,6};
	
		int a1 = a.length;
       
        int b1 = b.length;
 
        int c1 = a1 + b1;
		System.out.print("First array : ");
		for (int i = 0; i < a1 ; i++) {
        
            System.out.print(a[i]+" ");
		}
		
		System.out.print("Second array : ");
		for (int i = 0; i < a1 ; i++) {
        
            System.out.print(a[i]+" ");
		}
		
  
       
        int[] c = new int[c1];
  
        for (int i = 0; i < a1; i++) {
           
            c[i] = a[i];
        }
  

        for (int i = 0; i < b1; i++) {
			c[a1 + i] = b[i];
        }
  
        System.out.println("After merging : ");
        for (int i = 0; i < c1; i++) {
        
            System.out.print(c[i]+" ");
        }
    }
}
  