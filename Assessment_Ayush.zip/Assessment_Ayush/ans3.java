import java.util.*;
public class ans3 {
	public static void main(String args[]) {
		boolean[][] array = {{true ,false ,true },{false ,true ,true}};
		int r_len =array.length;
		int c_len = array[0].length;
		
		for (int i =0 ; i< r_len ;i++){
			for (int j =0 ;j< c_len; j++)
			{
				if (array[i][j])
				{
					System.out.print("t ");
				}
				else{
					System.out.print("f ");
				}
			}
			System.out.println();
		}
	}
}