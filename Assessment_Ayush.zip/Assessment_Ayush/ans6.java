import java.util.*;
public class ans6 {
	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		System.out.print("Enter the Number: ");
		int num=s.nextInt();
		String st = "";
		int z = 0;
		
		while(num>0) {
			if(num%2==0) {
				st += "0";
				z++;
			}
			else {
				st+="1";
			}
			num/=2;
		}
		char c[]=st.toCharArray();
		for(int i=c.length-1;i>=0;i--){
			System.out.print(c[i]);
		}
		System.out.println("\nNumber of Zero bits: "+z);
	}
}