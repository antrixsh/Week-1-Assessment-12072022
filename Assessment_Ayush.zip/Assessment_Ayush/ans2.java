import java.util.*;
public class ans2 {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter First no.");
		double n1 = sc.nextDouble();
		System.out.println("Enter second no.");
		double n2 = sc.nextDouble();
		System.out.println(n1 >0 && n1 < 1 && n2  > 0 && n2 < 1);
	}
}