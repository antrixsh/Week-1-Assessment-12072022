class Answer8{
    public static void main(String args[]){
        int arr1[]={1,3,4,5};
        int arr2[]={2,4,6,8};
        int arr3[]=new int[arr1.length+arr2.length];
        int n=0;
        for(int i=0;i<arr1.length;i++){
            arr3[n++]=arr1[i];
        }
        for(int i=0;i<arr2.length;i++){
            arr3[n++]=arr2[i];
        }
        for(int i=0;i<arr3.length;i++){
            System.out.print(arr3[i] +" ");
        }
    }
}