import java.util.Scanner;
class Answer2{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("Input first number: ");
        double d1=sc.nextDouble();
        System.out.println("Input second number: ");
        double d2=sc.nextDouble();
        boolean b=(d1>0 && d1<1 && d2>0 && d2<1) ? true:false;
        System.out.println(b);
    }
}