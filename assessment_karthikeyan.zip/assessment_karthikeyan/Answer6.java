import java.util.Scanner;
class Answer6{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("Input first number :");
        int num=sc.nextInt();
        int num1=num;
        String s="";
        int zcount=0;
        while(num1>0){
            if(num1%2==0){
                s+="0";
                zcount++;
            }else{
                s+="1";
            }
            num1/=2;
        }
        char c[]=s.toCharArray();
        int len=c.length;
        char c1[]=new char[len];
        for(int i=0;i<c.length;i++){
            c1[len-1]=c[i];
            len--;
        }
        System.out.print("Binary representation of "+num+" is:");
        for(int i=0;i<c1.length;i++){
            System.out.print(c1[i]);
        }
        System.out.println("\nNumber of zero bits: "+zcount);
    }
}