import java.util.*;
class Answer1{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("Input first number: ");
        int num1=sc.nextInt();
        System.out.println("Input second number: ");
        int num2=sc.nextInt();
        System.out.println("Input third number: ");
        int num3=sc.nextInt();
        System.out.println("Input fourth number: ");
        int num4=sc.nextInt();
        String s=(num1 == num2 && num2 == num3 && num3 == num4)? "Numbers are equal":"Numbers are not equal!";
        System.out.println(s);
    }
}