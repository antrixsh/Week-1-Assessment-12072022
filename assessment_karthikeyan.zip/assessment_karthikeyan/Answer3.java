class Answer3{
    public static void main(String args[]){
        boolean arr[][]={{true,false,true},{false,true,false}};
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[0].length;j++){
                if(arr[i][j]==true){
                    System.out.print("t ");
                }else{
                    System.out.print("f ");
                }
            }
            System.out.println();
        }
    }
}