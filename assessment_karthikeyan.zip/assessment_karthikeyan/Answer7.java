class Answer7{
    public static void main(String args[]){
        int arr[]={2,2,2,2,2};
        int newarr[]=new int[arr.length];
        int newsize=0;
        for(int i=0;i<arr.length-1;i++){
            if(arr[i]!=arr[i+1]){
                newarr[newsize++]=arr[i];
            }
        }
        newarr[newsize++]=arr[arr.length-1];
        System.out.print("output array is :");
        for(int i=0;i<newsize;i++){
            System.out.print(newarr[i]);
        }
        System.out.println("\n new size :" +newsize);
    }
}