import java.util.Scanner;
class Answer5{
    public static void main(String args[]){
        int arr[]={1,4,17,7,25,3,100};
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter value for k:");
        int k=sc.nextInt();
        for(int i=0;i<arr.length;i++){
            for(int j=i+1;j<arr.length;j++){
                if(arr[i]<arr[j]){
                    arr[i]=arr[j]+arr[i]-(arr[j]=arr[i]);
                }
            }
        }
        for(int i=0;i<k;i++){
            System.out.print(arr[i]+ " ");
        }
    }
}