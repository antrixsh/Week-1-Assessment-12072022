import java.util.Scanner;

public class answer4 {
	public static void main(String arg[]) {
		int a, b;  
	    System.out.println("Enter total rows and columns: ");  
	    Scanner s = new Scanner(System.in);  
	    
		int row = s.nextInt();  
	    int column = s.nextInt();  
	    int array[][] = new int[row][column];  
	    System.out.println("Enter matrix Value:");  
	    
		for(a = 0; a < row; a++)  
	    {  
	    for(b = 0; b < column; b++)   
	     {  
	        array[a][b] = s.nextInt();  
	        System.out.print(" ");  
	     }  
	    } 
	    System.out.println("Matrix value before Change ");  
	    for(a = 0; a < row; a++)  
	        {  
	    for(b = 0; b < column; b++)  
	     {  
	        System.out.print(array[a][b]+" ");  
	        }  
	        System.out.println(" ");
	        }  
	    System.out.println("Matrix value after change ");  
	    for(a = 0; a < column; a++)  
	        {  
	        for(b = 0; b < row; b++)  
	      {  
	        System.out.print(array[b][a]+" ");  
	      }  
	        System.out.println(" ");  
	        }  
	}

}