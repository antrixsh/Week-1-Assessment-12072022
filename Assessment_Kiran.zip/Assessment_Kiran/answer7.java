class Main {
    static int remove(int arr[], int n)
    {
      if (n == 0 || n == 1)
        return n;
  
      int[] temp = new int[n];
  
      int b = 0;
      for (int a = 0; a < n - 1; a++)
            
       if (arr[a] != arr[a + 1])
        temp[b++] = arr[a];
  
        
      temp[b++] = arr[n - 1];
  
      for (int a = 0; a < b; a++)
        arr[a] = temp[a];
  
        return b;
    }

    public static void main(String[] args)
    {
        int arr[] = { 2,2,2,2,2};
        int n = arr.length;
        n = remove(arr, n);
  
        for (int a = 0; a < n; a++)
          System.out.print(arr[a] + " ");
    }
}