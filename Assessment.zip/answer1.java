import java.util.Scanner;
public class answer1 {
	public static void main(String[] args) {
		 Scanner in = new Scanner(System.in);
		 System.out.print("Input first number: ");
         int a1 = in.nextInt();
         System.out.print("Input second number: ");
         int a2 = in.nextInt();
		 System.out.print("Input third number: ");
         int a3 = in.nextInt();
         System.out.print("Input fourth number: ");
         int a4 = in.nextInt();		
		
		if (a1 == a2 && a2 == a3 && a3 == a4) 
		{
			System.out.println("Numbers are equal.");
                               }
		else
			{
			System.out.println("Numbers are not equal!");
		}
	}
}