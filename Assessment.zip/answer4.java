import java.util.Scanner;
public class answer4 {
	public static void main(String[] args) {
		int[][] two_dimensional = {
				{10, 20, 30},
				{40, 50, 60}
		};
		System.out.print("Original Array:\n");
		print_array(two_dimensional);
		System.out.print("After changing the rows and columns of array:\n");
		transpose(two_dimensional);
		}
	
	private static void transpose(int[][] two_dimensional) {
		
		int[][] newtwo_dimensional = new int[two_dimensional[0].length][two_dimensional.length];
		
		for (int i = 0; i < two_dimensional.length; i++) {
			for (int j = 0; j < two_dimensional[0].length; j++) {
				newtwo_dimensional[j][i] = two_dimensional[i][j];
			}
		}
		
		print_array(newtwo_dimensional);
	}
	private static void print_array(int[][] two_dimensional) {
		for (int i = 0; i < two_dimensional.length; i++) {
			for (int j = 0; j < two_dimensional[0].length; j++) {
				System.out.print(two_dimensional[i][j] + " ");
			}
			System.out.println();
		}
	
	}
}