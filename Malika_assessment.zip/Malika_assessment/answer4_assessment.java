import java.util.*;

 public class answer4_assessment{
    public static void main(String[]args)

{

    Scanner sc=new Scanner(System.in);

    int m,n;

    System.out.println("ENTER R N C");
    m=sc.nextInt();
    n=sc.nextInt();
    int [][]a=new int[m][n];
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            a[i][j]=sc.nextInt();
        }
    }

    int [][]a1=new int[n][m];
    for(int j=0;j<m;j++){
        for(int i=0;i<n;i++){
            a1[i][j]=a[j][i];
        }
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            System.out.println(a1[i][j]);
        }
    }

    
}
}