import java.util.*;

public class answer8_assessment{
	public static void RR(int a[],int n){
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<n;i++){
			a[i]=sc.nextInt();
}}

	public static void main(String[] args){
		
		Scanner sc=new Scanner(System.in);
		System.out.print("enter n1");
		int n1=sc.nextInt();
		int array[]=new int[n1];
		System.out.print("Enter array1:");
		RR(array,n1);
		System.out.print("Enter n2:");
		int n2=sc.nextInt();
		int array1[]=new int[n2];
		System.out.print("Enterarray2:");
		RR(array1,n2);
		int Q=n1+n2;
		int array2[]=new int[Q];
		for(int i=0;i<n1;i++){
			array2[i]=array[i];}
		for(int i=n1;i<Q;i++){
			array2[i]=array1[i-n1];}
		System.out.print("Output is:");
		for(int i=0;i<Q;i++){
				System.out.print(array2[i]+" ");
}
}
}