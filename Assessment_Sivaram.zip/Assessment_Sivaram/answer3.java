import java.util.*;

public class answer3
{  
public static void main(String[] args) {
   boolean [][]a=new boolean[3][3];
Scanner sc= new Scanner(System.in);
for(int i=0;i<2;i++){
   for(int j=0;j<3;j++){
       boolean d=sc.nextBoolean();
       a[i][j]=d;
   }
}

for(int i=0;i<3;i++){
   for(int j=0;j<3;j++){
       if(a[i][j]==true)
        System.out.println("t");
        else
         System.out.println("f");

   }
}

}
}