import java.util.*;

class answer6{
    public static void main(String[]args)

{

    Scanner sc=new Scanner(System.in);
    int k;
    k=sc.nextInt();

   int ans;
   int count=0;
   while(k>0){
       ans=k%2;
       k=k/2;
       if(ans==0){
           count=count+1;

       }
   }
     System.out.println(count);  



}
}