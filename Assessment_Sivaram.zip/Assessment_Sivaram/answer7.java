
import java.util.*;
class answer7
{
    
     public static void main(String [] args){
         int arr[]={1,2,2,2,3};
         int i=0;
         int  n=arr.length;
         if(n==0)return ;
         for(int j=1;j<n;j++){
             if(arr[j]!=arr[i]){
                 i=i+1;
                arr[i]=arr[j];
             }
         }
         for(int k=0;k<i+1;k++){
             System.out.println(arr[k]);
         }
     }
}

