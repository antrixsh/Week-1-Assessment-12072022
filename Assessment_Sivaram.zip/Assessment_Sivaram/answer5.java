import java.util.*;
class answer5 {
    
    static void large(int[] nums, int k) {
        
        PriorityQueue<Integer> pq = new PriorityQueue<>();
        for (int num : nums) {
            pq.add(num);
            if (pq.size() > k) {
                pq.poll();
            }
        }
         while (!pq.isEmpty()) {
            System.out.print(pq.peek() + " ");
            pq.poll();
        }
    }

 public static void main(String[] args)
    {
        int a[]
            = { 11,44,60,100,200,500,300 };
        int n = a.length;
        System.out.println("Enter the number of largest numbers need");
        Scanner sc=new Scanner(System.in);
        
        int k ;
        k=sc.nextInt();
        
        System.out.print(k + " largest elements are : ");
     
        large(a, k);
        
    }
}