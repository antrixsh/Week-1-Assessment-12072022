import java.util.*;
public class answer2
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
		double a,b;
		System.out.println("Enter two numbers");
		a=sc.nextDouble();
		b=sc.nextDouble();
		System.out.println("Input first number :" +a);
		System.out.println("Input second number :" +b);
		if(a>0 && a<1 && b>0 && b<1)
		  System.out.println("true");
		else{
		    System.out.println("false");
		}  
	}
}