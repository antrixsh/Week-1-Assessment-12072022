import java.util.*;
class answer8
{

     public static void main(String [] args){
         int arr1[]={1,2,2,2,3};
         int arr2[]={2,3,6,8};
         int n1=arr1.length ;
         int n2=arr2.length;
         int n=n1+n2;
         int []arr3=new int[n];

         for(int k=0;k<arr1.length;k++){
             arr3[k]=arr1[k];
         }
         int m=0;
         for(int k=arr1.length;m<arr2.length;k++){
             arr3[k]=arr2[m];
             m++;
         }
         for(int k=0;k<n;k++){
             System.out.println(arr3[k]);
         }
     }
}