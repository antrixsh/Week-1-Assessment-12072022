import java.util.*;
public class answer1
{
	public static void main(String[] args) {
		int a,b,c,d;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter four numbers");
		a=sc.nextInt();
		b=sc.nextInt();
		c=sc.nextInt();
		d=sc.nextInt();
		if(a==b && b==c && c==d){
		    System.out.println("Input first number :" +a);
		    System.out.println("Input second number :" +b);
		    System.out.println("Input third number :" +c);
		    System.out.println("Input fourth number :" +d);
		    System.out.println("Numbers are equal!");
		}
		else{
		    System.out.println("Input first number :" +a);
		    System.out.println("Input second number :" +b);
		    System.out.println("Input third number :" +c);
		    System.out.println("Input fourth number :" +d);
		    System.out.println("Numbers are not equal!");
		}
	
	}
}