import java.util.*;

public class ans8 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Length of First Array: ");
        int len1 = sc.nextInt();
        int arr1[] = new int[len1];
        int i, val;

        for(i=0; i<len1; i++)
        {
            System.out.print("Enter next value:");
            val = sc.nextInt();
            arr1[i] = val;
        }

        System.out.print("Enter Length of Second Array: ");
        int len2 = sc.nextInt();
        int arr2[] = new int[len2];
        
        for(i=0; i<len2; i++)
        {
            System.out.print("Enter next value:");
            val = sc.nextInt();
            arr2[i] = val;
        }

        int arr3[] = new int[len1 + len2];

        for(i=0; i<len1; i++)
        {
            arr3[i] = arr1[i];
        }

        for(i=0; i<len2; i++)
        {
            arr3[i + len1] = arr2[i];
        }

        System.out.print("[ ");

        for(i=0; i<len1+len2; i++)
            System.out.print(arr3[i] + " ");

        System.out.print("]");
    }
}
