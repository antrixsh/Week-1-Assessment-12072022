import java.util.*;

public class ans6 {
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Input First Number: ");
        int num = sc.nextInt();
        int len=1, temp=num;

        while(temp!=1)
        {
            len++;
            temp /= 2;
        }
        
        int arr[] = new int[len];
        arr[0] = 1;
        for(int i=len-1; i>0; i--)
        {
            arr[i] = num%2;
            num /=2;
        }
        int count=0;
        System.out.print("Binary Representation: ");
        for(int i=0; i<len; i++)
        {
            System.out.print(arr[i]);
            if(arr[i]==0)
                count++; 
        }
        System.out.println();
        System.out.println("Number Of Zero Bits: " + count);
        
    }
}
