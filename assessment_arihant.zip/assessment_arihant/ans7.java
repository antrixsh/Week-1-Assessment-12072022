import java.util.*;

public class ans7 {
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Array Length: ");
        int len = sc.nextInt();
        int arr[] = new int[len];
        int val, temp, max, pos=0, i, j, count=1;
        
        for(i=0; i<len; i++)
        {
            System.out.print("Enter next value:");
            val = sc.nextInt();
            arr[i] = val;
        }

        for(i=0; i<len; i++)
        {
            max=0;
            for(j=i; j<len; j++)
            {
                if(arr[j]>max)
                {
                    max = arr[j];
                    pos = j;
                }
            }

            temp = arr[pos];
            arr[pos] = arr[i];
            arr[i] = temp;
        }

        for(i=0; i<len-1; i++)
        {
            if(arr[i]!=arr[i+1])
            {
                count++;
            }
        }
        
        int newarr[] = new int[count];
        j=1;
        newarr[0] = arr[0];
        for(i=0; i<len-1; i++)
        {
            if(arr[i]!=arr[i+1])
            {
                newarr[j] = arr[i+1];
                j++;
            }
        }
        
        System.out.print("New Array Is: [ ");

        for(i=0; i<count; i++)
            System.out.print(newarr[i] + " ");

        System.out.println("]");
        System.out.println("New Array Length is " + newarr.length);
    }
}
