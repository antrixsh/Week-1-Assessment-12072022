import java.util.*;

public class ans4 {
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Number of Rows: ");
        int r = sc.nextInt();
        System.out.print("Enter Number of Columns: ");
        int c = sc.nextInt();
        int arr[][] = new int[r][c];
        int arr1[][] = new int[c][r];
        int val, i, j;
        for(i=0; i<r; i++)
        {
            for(j=0; j<c; j++)
            {
                System.out.print("Enter Next Value: ");
                val = sc.nextInt(); 
                arr[i][j] = val;
            }
        }

        for(i=0; i<r; i++)
        {
            for(j=0; j<c; j++)
            {
                arr1[j][i] = arr[i][j];
            }
        }

        for(i=0; i<c; i++)
        {
            for(j=0; j<r; j++)
            {
                System.out.print(arr1[i][j] + " ");
            }
            System.out.println();
        }
    }
}
