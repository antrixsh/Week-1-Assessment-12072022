import java.util.*;

public class ans1
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter First Number: ");
		int n1 = sc.nextInt();
		System.out.print("Enter Second Number: ");
		int n2 = sc.nextInt();
		System.out.print("Enter Third Number: ");
		int n3 = sc.nextInt();
		System.out.print("Enter Fourth Number: ");
		int n4 = sc.nextInt();
		if(n1 == n2 && n1==n3 && n1==n4)
		{
			System.out.println("Numbers Are Equal!");
		}
		else
		{
			System.out.println("Numbers Are Not Equal!");
		}
	}
}