import java.util.*;

public class ans5 {
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Array Length: ");
        int len = sc.nextInt();
        int arr[] = new int[len];
        int val, temp, max, pos=0, i, j;
        
        for(i=0; i<len; i++)
        {
            System.out.print("Enter next value: ");
            val = sc.nextInt();
            arr[i] = val;
        }

        for(i=0; i<len; i++)
        {
            max=0;
            for(j=i; j<len; j++)
            {
                if(arr[j]>max)
                {
                    max = arr[j];
                    pos = j;
                }
            }

            temp = arr[pos];
            arr[pos] = arr[i];
            arr[i] = temp;
        }

        System.out.print("Enter Number Of Elements To Find: ");
        int k = sc.nextInt();
        if(k<=arr.length)
        {
            for(i=0; i<k; i++)
            {
                System.out.println(arr[i]);
            }
        }
        else
        {
            System.out.println("Index Out Of Bounds!");
        }
    }
}
