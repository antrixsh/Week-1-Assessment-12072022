import java.util.Scanner;

public class Answer8{
	public static void readarray(int array[],int n){
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<n;i++){
			array[i]=sc.nextInt();
}}

	public static void main(String[] args){
		
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the number of elements in array1:");
		int a=sc.nextInt();
		int array1[]=new int[a];
		System.out.print("Enter the array1:");
		readarray(array1,a);
		System.out.print("Enter the number of elements in array2:");
		int b=sc.nextInt();
		int array2[]=new int[b];
		System.out.print("Enter the array2:");
		readarray(array2,b);
		int c=a+b;
		int array3[]=new int[c];
		for(int i=0;i<a;i++){
			array3[i]=array1[i];}
		for(int i=a;i<c;i++){
			array3[i]=array2[i-a];}
		System.out.print("Output:");
		for(int i=0;i<c;i++){
				System.out.print(array3[i]+" ");
}
}
}

		
	
