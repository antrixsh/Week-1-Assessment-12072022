import java.util.Scanner;
public class Answer3{
	public static void main(String[] args){
		boolean array[][] = new boolean[2][3];
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the array:");
		for(int i=0;i<2;i++){
			for(int j=0;j<3;j++){
				array[i][j]=sc.nextBoolean();
				if(array[i][j] == true)
					System.out.print('t'+" ");
				else
					System.out.print('f'+" ");
				}
			System.out.println();
		}			
}
}