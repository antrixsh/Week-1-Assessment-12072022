import java.util.Scanner;
public class Answer4{
	public static void print(int m, int n, int array[][]){
	for(int i=0;i<m;i++){
		for(int j=0;j<n;j++){
				System.out.print(array[i][j]+" ");
}
		System.out.println();
}
}
	public static void main(String[] args){
		int A[][]=new int[2][3];
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the array:");
		for(int i=0;i<2;i++){
		for(int j=0;j<3;j++){
			A[i][j]=sc.nextInt();
}}
		System.out.println("Original array:");
		print(2,3,A);

		int B[][]=new int[3][2];
		for(int i=0;i<3;i++){
		for(int j=0;j<2;j++){
				B[i][j]=A[j][i];
}}
		System.out.println("After changing rows and columns of the array:");
		print(3,2,B);

}
}