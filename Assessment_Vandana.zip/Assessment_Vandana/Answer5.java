import java.util.*;
public class Answer5{
	public static void print(int m, int array[]){
	for(int i=0;i<m;i++){
				System.out.print(array[i]+" ");
}
}
	public static void main(String[] args){
		
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the number of elements in array:");
		int n=sc.nextInt();
		System.out.print("Enter the array:");
		int array[]=new int[n];
		for(int i=0;i<n;i++){
			array[i]=sc.nextInt();
}
		System.out.print("Enter the value of k:");
		int k= sc.nextInt();
		if(k>n)
			System.out.print("Error: k value is more than number of elements in the array");
		else{
		System.out.println("Original array:");
		print(n,array);
		int temp;
		for(int i=0;i<n-1;i++){
		for(int j=0;j<n-i-1;j++){
				if(array[j]<array[j+1]){
				temp=array[j];
				array[j]=array[j+1];
				array[j+1]=temp;}
}}
		System.out.println();
		System.out.println(k+" largest elements of the said array are:");
		print(k,array);
		}

}
}