import java.util.Scanner;
public class Answer2{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		System.out.println("Input first number:");
		double n1=sc.nextDouble();
		System.out.println("Input second number:");
		double n2=sc.nextDouble();
		if(n1>0 && n1<1 && n2>0 && n2<1)
			System.out.println("True");
		else
			System.out.println("False");
}
}

		
		