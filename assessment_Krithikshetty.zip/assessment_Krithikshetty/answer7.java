import java.util.*;
public class answer7 {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int[] arr=new int[]{2,2,2,2,2};
        for (int i = 0; i < 5; i++)
        {
            int j;
            for (j = 0; j < i; j++)
            if (arr[i] == arr[j])
                break;
            if (i == j)
            System.out.print( arr[i] + " ");
        }
           
        }
        

    }    
}
