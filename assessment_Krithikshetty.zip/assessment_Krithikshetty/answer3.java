import java.util.*;
import java.lang.*;
public class answer3 {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        String[][] s=new String[2][3];
        for(int i=0;i<2;i++){
            for(int j=0;j<3;j++){
                s[i][j]=sc.nextLine();
            }
        }
        System.out.print(s[0][0]);
        for(int i=0;i<2;i++){
            for(int j=0;j<3;j++){
                if(s[i][j]=="true"){
                    System.out.print("t ");
                }
                else{
                    System.out.print("f ");
                }
                System.out.println(" ");
            }
        }

    }
    
}
