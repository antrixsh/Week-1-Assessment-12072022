import java.util.*;
public class answer1 {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter 4 numbers");
        int[] a=new int[4];
        for (int i=0;i<4;i++)
        {
            a[i]=sc.nextInt();
        }
        if(a[0]==a[1] & a[1]==a[2] &a[2]==a[3]){
            System.out.print("equal");
        }
        else{
            System.out.print("Not equal");
        }
    }
    
}
