import java.util.*;
public class answer6 {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("enter a number");
        int n=sc.nextInt();
        int count=0;
        System.out.print("binary:");
        while (n > 0) {
            int r = n % 2;
            System.out.print(r);
            n /= 2;
            if(r==0){
                count+=1;
            }
        }
        System.out.println(" ");
        System.out.print("Number of 0's "+count);
    }
    
}
