public class answer4 {
    public static void main(String args[]){
        int n=2,m=3;
        int[][] arr={{10,20,30},{40,50,60}};
        int[][]ar = new int[3][2];
        for (int i=0;i<n;i++){
            for (int j=0;j<m;j++){
                ar[j][i]=arr[i][j];
                System.out.print(arr[i][j]+" ");
            }
            System.out.println(" ");
        }
        System.out.println(" ");
        for (int i=0;i<m;i++){
            for (int j=0;j<n;j++){
                System.out.print(ar[i][j]+" ");
            }
            System.out.println(" ");
        }

    }
}