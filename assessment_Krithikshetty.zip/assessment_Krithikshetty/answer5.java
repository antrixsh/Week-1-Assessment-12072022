import java.util.*;;
public class answer5 {
    public static void main(String[] args){
        
        
        Scanner sc=new Scanner(System.in);
        int[] a=new int[]{1, 4, 17, 7, 25, 3, 100};
        Arrays.sort(a);
        System.out.print("enter k maximum elements");
        int k=sc.nextInt();
        for (int i=6;i>=7-k;i--){
            System.out.println(a[i]);
        }
    }
}
