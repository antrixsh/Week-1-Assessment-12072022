public class answer8 {
    public static void main(String[] args){
        int[] a1={1,3,5,7};
        int[] a2={2,4,6,8};
        int[] a3=new int[10];
        for(int i=0;i<a1.length;i++)
        {
            a3[i]=a1[i];
        }
        for(int i=0;i<a2.length;i++)
        {
            a3[i+a1.length]=a2[i];
        }
        for(int i=0;i<a1.length+a2.length;i++)
        {
            System.out.println(a3[i]);
        }
        
    }
    
}
