/*Q. 3 Write a Java program to print the contents of a two-dimensional Boolean array where t will represent true and f will represent false
Sample array: array = {{true, false, true}, {false, true, false}}; Expected Output : t f t f t f*/

import java.util.Scanner;
public class AnsThree{
 public static void main(String[] args)
 {
  boolean[][] a={{true,false,true},
                  {false,true,false}};

  int r_len=a.length;
  int c_len=a[0].length;
   
   for(int i=0;i<r_len;i++)
   {
    for(int j=0;j<c_len;j++)
	{
	if(a[i][j]){
	 System.out.print("t");
	 }
	 else
	 {
	 System.out.print("f");
	 }
	 }
	 System.out.println();
	 }
 }
 }



