/*Q. 1 Write a Java program that accepts four integer from the user and prints equal if all four are equal, and not equal otherwise.*/

import java.util.Scanner;
public class AnsOne{
public static void main(String[] args)
{
 Scanner sc=new Scanner(System.in);
 System.out.println("enter the four input");
 int i1=sc.nextInt();
 int i2=sc.nextInt();
 int i3=sc.nextInt();
 int i4=sc.nextInt();
if(i1==i2 && i2==i3 && i3==i4){
System.out.println("all four are equall");
}
else 
{
System.out.println(" Not equal");
}
}
}
 
