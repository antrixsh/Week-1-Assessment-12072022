/*Q. 4 Write a Java program to print an array after changing the rows and columns of a given two-dimensional array.*/
import java.util.Scanner;

public class AnsFour{
	public static void main(String[] args) {
		int[][] a = new int[a[0].length][a.length];
		int[][] a = {
				{10, 20, 30},
				{40, 50, 60}
		};
		
		
		
		
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[0].length; j++) {
				a[j][i] = a[i][j];
			}
		}
		
		
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a.length; j++) {
				System.out.print(a[i][j] + " ");
			}
			System.out.println();
		}
	
	}
}