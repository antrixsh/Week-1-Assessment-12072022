/*Q. 2 Write a Java program that accepts two double variables and test if both strictly between 0 and 1 and false otherwise.*/

import java.util.Scanner;
public class AnsTwo{
public static void main(String[] args)
{
 Scanner sc=new Scanner(System.in);
 System.out.println("enter the 2 input");
 double i1=sc.nextDouble();
 double i2=sc.nextDouble();
 
if(i1>0 && i1<1 && i2>0 && i2<1){
System.out.println("True, both varibles are between 0 and 1");
}
else 
{
System.out.println("false");
}
}
}