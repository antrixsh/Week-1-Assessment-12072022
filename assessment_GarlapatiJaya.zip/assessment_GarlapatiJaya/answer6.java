import java.util.*;
public class answer6{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		System.out.print("Input first number:");
		int n=sc.nextInt();
		int rem,c=0;
		String x="";
		
		while(n > 0){
            rem = n % 2;
            if(rem == 1){
                c++;
            }
            x = rem + "" + x;
            n = n / 2;
        }
		System.out.println("Binary representation is: "+x);
		System.out.print("Number of zero bits:"+c);
	}
}