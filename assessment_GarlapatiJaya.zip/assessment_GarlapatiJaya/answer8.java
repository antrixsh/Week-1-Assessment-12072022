import java.util.*;
public class answer8{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no of values in a1:");
		int n1=sc.nextInt();
		System.out.println("Enter no of values in a2:");
		int n2=sc.nextInt();
		System.out.println("Enter values in a1:");
		int a1[]=new int[n1];
		for(int i=0;i<n1;i++){
			a1[i]=sc.nextInt();
		}
		System.out.println("Enter values in a2:");
		int a2[]=new int[n2];
		for(int i=0;i<n2;i++){
			a2[i]=sc.nextInt();
		}
		int c=n1+n2;
		int a3[]=new int[c];
		for(int i=0;i<n1;i++){
			a3[i]=a1[i];
		}
		for(int i=0;i<n2;i++){
			a3[n1+i]=a2[i];
		}
		System.out.println("merged:");
		for(int i=0;i<c;i++){
			System.out.println(a3[i]+" ");
		}
		
		}
}