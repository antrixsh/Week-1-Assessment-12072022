import java.util.*;
public class answer7{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no of values in array:");
		int n=sc.nextInt();
		System.out.println("Enter values of array:");
		int a[]=new int[n];
		for(int i=0;i<n;i++){
			a[i]=sc.nextInt();
		}
		if(n==0 || n==1){
			System.out.println(n);
		}
		int temp[]=new int[n];
		int j=0;
		for(int i=0;i<n-1;i++){
			if(a[i]!=a[i+1]){
				temp[j++]=a[i];
			}
		}
		temp[j++]=a[n-1];
		for(int i=0;i<j;i++){
			a[i]=temp[i];
			System.out.println("a[] : "+a[i]);
		}
		System.out.println("New size: "+j);
	}
}