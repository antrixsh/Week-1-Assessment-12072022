import java.util.*;
public class answer5{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no of value in array");
		int n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("Original Array:");
		for(int i=0;i<n;i++){
			a[i]=sc.nextInt();
		}
		System.out.println("Enter k value");
		int k=sc.nextInt();
		Arrays.sort(a);
		System.out.println(k+" largest elements of the said array are: ");
		for(int i=n-1;k>0;k--,i--){
			System.out.print(a[i]+" ");
		}
	}
}