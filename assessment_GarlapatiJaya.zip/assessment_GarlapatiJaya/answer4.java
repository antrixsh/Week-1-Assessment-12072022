import java.util.*;
public class answer4{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		int a1[][]=new int[2][3];
		int a2[][]=new int[3][2];
		System.out.println("Original Array:");
		for(int i=0;i<2;i++){
			for(int j=0;j<3;j++){
				a1[i][j]=sc.nextInt();
			}
		}
		System.out.println("After changing the rows and columns of the said array: ");
		for(int i=0;i<3;i++){
			for(int j=0;j<2;j++){
				a2[i][j]=a1[j][i];
				System.out.print(a2[i][j]+" ");
			}
			System.out.println();
		}
		
		}
}