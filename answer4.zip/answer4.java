package assignment05072022;
import java.util.Scanner;
class answer4 {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of rows ");
		int row=sc.nextInt();
		System.out.println("Enter number of columns ");
		int col=sc.nextInt();
int arr1[][]=new int[row][col];
int arr2[][]=new int[col][row];
System.out.println("enter values");
for(int i=0;i<row;i++) {
for(int j=0;i<col;j++) {
arr1[i][j]=sc.nextInt();
}
}
for(int i=0;i<col;i++) {
for(int j=0;j<0;j++) {
arr2[i][j]=arr[j][i];
System.out.print(arr2[i][j] +" ");
}
System.out.println();
}
}
}